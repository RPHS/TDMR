# coding=utf-8
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import os

os.environ['CUDA_VISIBLE_DEVICES'] = '1'

import pandas
import pandas as pd

import os
from sklearn.model_selection import KFold

import torch as th


# -----------------------------------------loading KG data and DDI 5-fold data------------------------------------------

# loading data
class DataLoaderKGADDI(object):

    def __init__(self, args, logging):
        self.args = args
        self.data_name = args.data_name
        self.use_pretrain = args.use_pretrain

        self.ddi_batch_size = args.DDI_batch_size
        self.kg_batch_size = args.kg_batch_size

        self.multi_type = args.multi_type

        self.entity_dim = args.entity_dim

        data_dir = args.data_dir

        train_file = os.path.join(data_dir, 'ADDI.txt')

        kg_file = os.path.join(data_dir, "kg2id.txt")

        self.DDI_train_data_X, self.DDI_train_data_Y, self.DDI_test_data_X, self.DDI_test_data_Y = self.load_ADDI_data(
            train_file)

        self.statistic_addi_data()

        triples = self.read_triple(kg_file)
        self.construct_triples(triples)

        self.print_info(logging)

        self.train_graph = None
        if self.use_pretrain == 1:
            self.load_pretrained_data()

    def load_ADDI_data(self, filename):

        train_X_data = []
        train_Y_data = []
        test_X_data = []
        test_Y_data = []

        traindf = pandas.read_csv(filename, delimiter='\t', header=None)
        data = traindf.values
        ADDI = data[:, 0:2]
        # 1123100,2
        print(ADDI.shape)
        Y = data[:, 2]
        label = np.array(list(map(int, Y)))

        print(ADDI.shape)
        print(label.shape)

        kfold = KFold(n_splits=10, shuffle=True, random_state=3)

        for train, test in kfold.split(ADDI, label):
            train_X_data.append(ADDI[train])
            train_Y_data.append(label[train])
            test_X_data.append(ADDI[test])
            test_Y_data.append(label[test])

        train_X = np.array(train_X_data)
        train_Y = np.array(train_Y_data)
        test_X = np.array(test_X_data)
        test_Y = np.array(test_Y_data)

        print('Loading ADDI data down!')

        return train_X, train_Y, test_X, test_Y

    def statistic_addi_data(self):
        data = []
        for i in range(len(self.DDI_train_data_X)):
            data.append(len(self.DDI_train_data_X[i]))
        self.n_addi_train = data

    def read_triple(self, path, mode='train', skip_first_line=False, format=[0, 1, 2]):
        heads = []
        tails = []
        rels = []
        print('Reading {} triples....'.format(mode))
        with open(path) as f:
            if skip_first_line:
                _ = f.readline()
            for line in f:
                triple = line.strip().split('\t')
                h, r, t = triple[format[0]], triple[format[1]], triple[format[2]]
                try:
                    heads.append(int(h))
                    tails.append(int(t))
                    rels.append(int(r))
                except ValueError:
                    print("For User Defined Dataset, both node ids and relation ids in the triplets should be int "
                          "other than {}\t{}\t{}".format(h, r, t))
                    raise
        heads = np.array(heads, dtype=np.int64)
        tails = np.array(tails, dtype=np.int64)
        rels = np.array(rels, dtype=np.int64)
        print('Finished. Read {} {} triples.'.format(len(heads), mode))

        return heads, rels, tails

    def load_kg(self, filename):
        kg_data = pd.read_csv(filename, sep='\t', names=['h', 'r', 't'], engine='python')
        kg_data = kg_data.drop_duplicates()
        return kg_data

    def construct_triples(self, kg_data):
        print("construct kg...")
        src, rel, dst = kg_data

        src, rel, dst = np.concatenate((src, dst)), np.concatenate((rel, rel)), np.concatenate((dst, src))
        self.kg_triple = np.array(sorted(zip(src, rel, dst)))
        # print(self.kg_triple.shape)

        self.n_relations = max(rel) + 1
        self.n_entities = max(max(src), max(dst)) + 1

        self.kg_train_data = self.kg_triple
        self.n_kg_train = len(self.kg_train_data)

        print('construct kg down!')

    def print_info(self, logging):

        logging.info('n_entities:         %d' % self.n_entities)
        logging.info('n_relations:        %d' % self.n_relations)
        logging.info('n_kg_train:         %d' % self.n_kg_train)
        logging.info('n_ddi_train:         %s' % self.n_addi_train)

    def load_pretrained_data(self):

        # load pretrained KG information

        transE_entity_path = 'embedding_data/entityVector_128.npz'
        transE_relation_path = 'embedding_data/relationVector_128.npz'
        transE_entity_data = np.load(transE_entity_path)
        transE_relation_data = np.load(transE_relation_path)
        transE_entity_data = transE_entity_data['embed']
        transE_relation_data = transE_relation_data['embed']

        # apply pretrained data
        self.entity_pre_embed = transE_entity_data
        self.relation_pre_embed = transE_relation_data




# ----------------------------------------------  Main model part  -----------------------------------------------------
