# -*- coding: utf-8 -*-
# @Time    : 2023/8/19 1:42 上午
# @Author  : Chen Mukun
# @File    : TDMR.py
# @Software: PyCharm
# @desc    :
import torch
from torch import nn

from processing.layer.GATLayer import GATLayer

import math

import torch
import torch.nn as nn
import torch.nn.functional as F

import dgl

"""
    Graph Transformer with edge features

"""
from processing.layer.HMGRLayer import GraphTransformerLayer
from processing.layer.MLPLayer import MLPReadout

EMB_INIT_EPS = 2.0
gamma = 12.0


class TDMRModel(nn.Module):

    def __init__(self, args, kg, n_entities, n_relations, n_layer, num_heads, n_time, entity_pre_embed=None,
                 relation_pre_embed=None):

        super(TDMRModel, self).__init__()
        self.use_pretrain = args.use_pretrain

        self.n_entities = n_entities
        self.n_relations = n_relations
        self.entity_pre_embed = entity_pre_embed
        self.relation_pre_embed = relation_pre_embed
        self.dim = args.dim

        self.pre_entity_dim = args.pre_entity_dim

        self.mess_dropout = eval(args.mess_dropout)

        self.ddi_l2loss_lambda = args.DDI_l2loss_lambda

        self.hidden_dim = args.entity_dim
        self.eps = EMB_INIT_EPS
        self.emb_init = (gamma + self.eps) / self.hidden_dim

        self.kg_layers = []
        self.mol_layers = []
        self.n_layers = n_layer
        self.init_atom = nn.Linear(68, self.hidden_dim)
        self.init_pharmacophore = nn.Linear(194, self.hidden_dim)
        self.init_bond = nn.Linear(16, self.hidden_dim)
        self.init_pharmacophore_bond = nn.Linear(34, self.hidden_dim)
        self.init_join_bond = nn.Linear(68 + 194, self.hidden_dim)
        self.mlp = MLPReadout(4 * self.hidden_dim, 258)
        for i in range(n_layer):
            self.kg_layers.append(GATLayer(kg, self.dim))
            self.mol_layers.append(GraphTransformerNet(self.dim, num_heads, n_time))

    def forward(self, mol_i, mol_j, drug_i, drug_j):
        mol_i.edges[('a', 'b', 'a')].data['x'] = self.init_bond(mol_i.edges[('a', 'b', 'a')].data['x'])
        mol_i.edges[('f', 'r', 'f')].data['x'] = self.init_pharmacophore_bond(
            mol_i.edges[('f', 'r', 'f')].data['x'])
        mol_i.apply_edges(lambda edges: {'x': self.init_join_bond(torch.cat(edges.src['x'], edges.dst['x']))},
                          etype=('f', 'j', 'a'))
        mol_i.apply_edges(lambda edges: {'x': self.init_join_bond(torch.cat(edges.src['x'], edges.dst['x']))},
                          etype=('a', 'j', 'f'))
        mol_i.nodes['a'].data['x'] = self.init_atom(mol_i.nodes['a'].data['x'])
        mol_i.nodes['f'].data['x'] = self.init_pharmacophore(mol_i.nodes['f'].data['x'])

        mol_j.edges[('a', 'b', 'a')].data['x'] = self.init_bond(mol_j.edges[('a', 'b', 'a')].data['x'])
        mol_j.edges[('f', 'r', 'f')].data['x'] = self.init_pharmacophore_bond(
            mol_j.edges[('f', 'r', 'f')].data['x'])
        mol_j.apply_edges(lambda edges: {'x': self.init_join_bond(torch.cat(edges.src['x'], edges.dst['x']))},
                          etype=('f', 'j', 'a'))
        mol_j.apply_edges(lambda edges: {'x': self.init_join_bond(torch.cat(edges.src['x'], edges.dst['x']))},
                          etype=('a', 'j', 'f'))
        mol_j.nodes['a'].data['x'] = self.init_atom(mol_j.nodes['a'].data['x'])
        mol_j.nodes['f'].data['x'] = self.init_pharmacophore(mol_j.nodes['f'].data['x'])
        mi = None
        mj = None
        di = self.entity_pre_embed[drug_i]
        dj = self.entity_pre_embed[drug_j]
        for n in range(self.n_layer):
            mi = self.mol_layers[n](mol_i, mol_i.ndata['x'], mol_i.edata['x'], di)
            mj = self.mol_layers[n](mol_j, mol_j.ndata['x'], mol_j.edata['x'], dj)

            di = self.kg_layers[n](self.entity_pre_embed, di, dj, mi, mj)
            dj = self.kg_layers[n](self.entity_pre_embed, di, dj, mi, mj)

        return self.mlp(torch.cat([torch.cat([mi, di]), torch.cat([mj, dj])]))


class GraphTransformerNet(nn.Module):
    def __init__(self, dim, num_heads, n_time):
        super().__init__()
        hidden_dim = dim
        num_heads = num_heads
        out_dim = hidden_dim
        dropout = 0.05
        n_layers = n_time
        self.readout = 'gru'
        self.device = 'gpu:0'

        self.layers = nn.ModuleList(
            [GraphTransformerLayer(hidden_dim, hidden_dim, num_heads, dropout, use_bias=False) for _ in
             range(n_layers - 1)])
        self.layers.append(
            GraphTransformerLayer(hidden_dim, out_dim, num_heads, dropout, use_bias=False))

        self.gru = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.mlp = MLPReadout(2 * hidden_dim, 1)

    def forward(self, g, h, e, drug_emb):
        # convnets
        for conv in self.layers:
            h, e = conv(g, h, e)
        g.ndata['h'] = h

        if self.readout == "sum":
            hg = dgl.sum_nodes(g, 'h')
        elif self.readout == "max":
            hg = dgl.max_nodes(g, 'h')
        elif self.readout == "mean":
            hg = dgl.mean_nodes(g, 'h')
        elif self.readout == "gru":
            x, _ = self.gru(g.ndata['h'])
            w_score = self.softmax(self.mlp(torch.cat([x, [drug_emb.reeat(x.shape[1])]], dim=1)))
            x = x.mul(w_score)
            hg = torch.sum(x, dim=1)
        else:
            hg = dgl.mean_nodes(g, 'h')
        return hg

    def loss(self, scores, targets):
        # loss = nn.MSELoss()(scores,targets)
        loss = nn.L1Loss()(scores, targets)
        return loss
