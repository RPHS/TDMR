# -*- coding: utf-8 -*-

import torch as th

import numpy as np
import torch.nn as nn
class Cross_stitch(nn.Module):

    def __init__(self):
        super(Cross_stitch, self).__init__()
        # self.out_dim=out_dim
        self.w_aa = nn.Parameter(th.Tensor(1, ))
        self.w_aa.data = th.tensor(np.random.random(), requires_grad=True)

        self.w_ab = nn.Parameter(th.Tensor(1, ))
        self.w_ab.data = th.tensor(np.random.random(), requires_grad=True)
        self.w_ba = nn.Parameter(th.Tensor(1, ))
        self.w_ba.data = th.tensor(np.random.random(), requires_grad=True)
        self.w_bb = nn.Parameter(th.Tensor(1, ))
        self.w_bb.data = th.tensor(np.random.random(), requires_grad=True)
        # np.random.random()

        print(self.w_aa)

    def forward(self, mol, drug_kg):
        mol = self.w_aa * mol + self.w_ab * drug_kg
        drug = self.w_ba * mol + self.w_bb * drug_kg

        print('shared parameters: w_aa:{:.4f}, w_ab:{:.4f}, w_ba:{:.4f}, w_bb:{:.4f}'.format(self.w_aa, self.w_ab,
                                                                                             self.w_ba, self.w_bb))

        return mol, drug