# -*- coding: utf-8 -*-
# @Time    : 2023/8/19 12:27 上午
# @Author  : Chen Mukun
# @File    : ATTGRULayer.py
# @Software: PyCharm
# @desc    : 

if __name__ == '__main__':
    pass
