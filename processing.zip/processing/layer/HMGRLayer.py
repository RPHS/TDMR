import torch
import torch.nn as nn
import torch.nn.functional as F

import dgl
import dgl.function as fn
import numpy as np

"""
    Graph Transformer Layer with edge features
    
"""

"""
    Util functions
"""


def src_dot_dst(src_field, dst_field, out_field):
    def func(edges):
        return {out_field: (edges.src[src_field] * edges.dst[dst_field])}

    return func


def scaling(field, scale_constant):
    def func(edges):
        return {field: ((edges.data[field]) / scale_constant)}

    return func


# Improving implicit attention scores with explicit edge features, if available
def imp_exp_attn(implicit_attn, explicit_edge):
    """
        implicit_attn: the output of K Q
        explicit_edge: the explicit edge features
    """

    def func(edges):
        return {implicit_attn: (edges.data[implicit_attn] * edges.data[explicit_edge])}

    return func


# To copy edge features to be passed to FFN_e
def out_edge_features(edge_feat):
    def func(edges):
        return {'e_out': edges.data[edge_feat]}

    return func


def exp(field):
    def func(edges):
        # clamp for softmax numerical stability
        return {field: torch.exp((edges.data[field].sum(-1, keepdim=True)).clamp(-5, 5))}

    return func


class MultiHeadAttentionLayer(nn.Module):
    def __init__(self, in_dim, out_dim, num_heads, use_bias):
        super().__init__()

        self.out_dim = out_dim
        self.num_heads = num_heads

        if use_bias:
            self.Q_a = nn.Linear(in_dim, out_dim * num_heads, bias=True)
            self.Q_f = nn.Linear(in_dim, out_dim * num_heads, bias=True)
            self.K_a = nn.Linear(in_dim, out_dim * num_heads, bias=True)
            self.K_f = nn.Linear(in_dim, out_dim * num_heads, bias=True)
            self.V_a = nn.Linear(in_dim, out_dim * num_heads, bias=True)
            self.V_f = nn.Linear(in_dim, out_dim * num_heads, bias=True)
            self.proj_e_aa = nn.Linear(in_dim, out_dim * num_heads, bias=True)
            self.proj_e_af = nn.Linear(in_dim, out_dim * num_heads, bias=True)
            self.proj_e_ff = nn.Linear(in_dim, out_dim * num_heads, bias=True)
        else:
            self.Q_a = nn.Linear(in_dim, out_dim * num_heads, bias=False)
            self.Q_f = nn.Linear(in_dim, out_dim * num_heads, bias=False)
            self.K_a = nn.Linear(in_dim, out_dim * num_heads, bias=False)
            self.K_f = nn.Linear(in_dim, out_dim * num_heads, bias=False)
            self.V_a = nn.Linear(in_dim, out_dim * num_heads, bias=False)
            self.V_f = nn.Linear(in_dim, out_dim * num_heads, bias=False)
            self.proj_e_aa = nn.Linear(in_dim, out_dim * num_heads, bias=False)
            self.proj_e_af = nn.Linear(in_dim, out_dim * num_heads, bias=False)
            self.proj_e_ff = nn.Linear(in_dim, out_dim * num_heads, bias=False)

    def propagate_attention(self, g):
        # Compute attention score
        g.apply_edges(src_dot_dst('K_h', 'Q_h', 'score'))  # , edges)

        # scaling
        g.apply_edges(scaling('score', np.sqrt(self.out_dim)))

        # Use available edge features to modify the scores
        g.apply_edges(imp_exp_attn('score', 'proj_e'))

        # Copy edge features as e_out to be passed to FFN_e
        g.apply_edges(out_edge_features('score'))

        # softmax
        g.apply_edges(exp('score'))

        # Send weighted values to target nodes
        eids = g.edges()
        g.send_and_recv(eids, fn.src_mul_edge('V_h', 'score', 'V_h'), fn.sum('V_h', 'wV'))
        g.send_and_recv(eids, fn.copy_edge('score', 'score'), fn.sum('score', 'z'))

    # def Q(self, h):
    #     bg.nodes['a'].data['f'] = self.act(self.w_atom(bg.nodes['a'].data['f']))
    #     bg.nodes['p'].data['f'] = self.act(self.w_pharm(bg.nodes['p'].data['f']))
    #     bg.edges[('p', 'r', 'p')].data['x'] = self.act(self.w_reac(bg.edges[('p', 'r', 'p')].data['x']))
    #     bg.nodes['a'].data['f_junc'] = self.act(self.w_junc(bg.nodes['a'].data['f_junc']))
    #     bg.nodes['p'].data['f_junc'] = self.act(self.w_junc(bg.nodes['p'].data['f_junc']))
    #
    # def K(self, h):
    #
    # def V(self, h):
    #
    # def proj_e(self,e):
    #     bg.edges[('a', 'b', 'a')].data['x'] = self.act(self.w_bond(bg.edges[('a', 'b', 'a')].data['x']))

    def forward(self, g, h, e):

        g.nodes['a'].data['Q_h'] = self.Q_a(g.nodes['a'].data['x']).view(-1, self.num_heads, self.out_dim)
        g.nodes['f'].data['Q_h'] = self.Q_f(g.nodes['f'].data['x']).view(-1, self.num_heads, self.out_dim)

        g.nodes['a'].data['K_h'] = self.K_a(g.nodes['a'].data['x']).view(-1, self.num_heads, self.out_dim)
        g.nodes['f'].data['K_h'] = self.K_f(g.nodes['f'].data['x']).view(-1, self.num_heads, self.out_dim)

        g.nodes['a'].data['V_h'] = self.V_a(g.nodes['a'].data['x']).view(-1, self.num_heads, self.out_dim)
        g.nodes['f'].data['V_h'] = self.V_f(g.nodes['f'].data['x']).view(-1, self.num_heads, self.out_dim)

        g.edges[('a', 'b', 'a')].data['proj_e'] = self.proj_e_aa(g.edges[('a', 'b', 'a')].data['x']).view(-1,
                                                                                                          self.num_heads,
                                                                                                          self.out_dim)

        g.edges[('f', 'r', 'f')].data['proj_e'] = self.proj_e_ff(g.edges[('f', 'r', 'f')].data['x']).view(-1,
                                                                                                          self.num_heads,
                                                                                                          self.out_dim)
        g.edges[('a', 'j', 'f')].data['proj_e'] = self.proj_e_af(g.edges[('a', 'j', 'f')].data['x']).view(-1,
                                                                                                          self.num_heads,
                                                                                                          self.out_dim)
        g.edges[('f', 'j', 'a')].data['proj_e'] = self.proj_e_af(g.edges[('f', 'j', 'a')].data['x']).view(-1,
                                                                                                          self.num_heads,
                                                                                                          self.out_dim)

        self.propagate_attention(g)

        h_out = g.ndata['wV'] / (g.ndata['z'] + torch.full_like(g.ndata['z'], 1e-6))  # adding eps to all values here
        e_out = g.edata['e_out']

        return h_out, e_out


class GraphTransformerLayer(nn.Module):
    """
        Param: 
    """

    def __init__(self, in_dim, out_dim, num_heads, dropout=0.05, use_bias=False):
        super().__init__()

        self.in_channels = in_dim
        self.out_channels = out_dim
        self.num_heads = num_heads
        self.dropout = dropout

        self.attention = MultiHeadAttentionLayer(in_dim, out_dim // num_heads, num_heads, use_bias)

        self.layer_norm_h = nn.LayerNorm(out_dim)
        self.layer_norm_e = nn.LayerNorm(out_dim)

        self.batch_norm_h = nn.BatchNorm1d(out_dim)
        self.batch_norm_e = nn.BatchNorm1d(out_dim)

        self.graphSage_layer_h = nn.ModuleList([nn.LeakyReLU(),
                                                nn.Linear(in_dim * 2, in_dim, bias=False),
                                                ])

        self.graphSage_layer_h = nn.ModuleList([nn.LeakyReLU(),
                                                nn.Linear(in_dim * 2, in_dim, bias=False),
                                                ])

    def forward(self, g, h, e):
        h_in = h
        e_in = e

        # multi-head attention out
        h_attn_out, e_attn_out = self.attention(g, h, e)

        h = h_attn_out.view(-1, self.out_channels)
        e = e_attn_out.view(-1, self.out_channels)

        h = F.dropout(h, self.dropout, training=self.training)
        e = F.dropout(e, self.dropout, training=self.training)

        h = self.layer_norm_h(h)
        e = self.layer_norm_e(e)

        h = self.batch_norm_h(h)
        e = self.batch_norm_e(e)

        h = torch.cat([h_in, h], dim=1)
        e = torch.cat([e_in, e], dim=1)
        h = self.graphSage_layer_h(h)
        e = self.graphSage_layer_e(e)

        return h, e

    def __repr__(self):
        return '{}(in_channels={}, out_channels={}, heads={}, residual={})'.format(self.__class__.__name__,
                                                                                   self.in_channels,
                                                                                   self.out_channels, self.num_heads,
                                                                                   self.residual)
