# -*- coding: utf-8 -*-

import os

if __name__ == '__main__':
    total_entities = 0
    drugs = open('entity/DrugSmlies.txt')

    for line in drugs:
        total_entities = int(line.strip().split('\t')[0]) + 1
    drugs.close()
    out = open('kg2id.txt', 'w')
    for file in os.listdir('relation'):
        r = file.split('.')[0]
        with open('relation/' + file) as f:
            for i in f:
                arr = i.strip().split('\t')
                out.write('\t'.join([arr[0], arr[1], str(int(arr[2]) + total_entities)]))
                out.write('\r\n')
            f.close()
        with open('entity/' + r + 'Set.txt')as f:
            tmp = 0
            for line in f:
                tmp = int(line.strip().split('\t')[0]) + 1
            total_entities += tmp
            f.close()
    out.close()
